/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package maClasse;

import java.util.Arrays;

/**
 *
 * @author Thiaw_Sakhir
 */
public class Calculator
{
    public int sum(int a, int b)
    {
        return a+b;
    }
    
      public int minus(int a, int b)
    {
        return a-b;
    }
      
    public int divide(int a, int b)
    {
        return a/b;
    }
    
    public int multiply(int a, int b)
    {
        return a*b;
    }
    
    public int min(int a, int b)
    {
        if(a<=b)
           return a;
        else 
            return b;
    }
    
    public int max(int a, int b)
    {
         if(a<=b)
           return b;
        else 
            return a;
    }
    
    public int minElement(int[] list)
    {
       Arrays.sort(list);
       return list[0];
    }
    
    public int maxElement(int[] list)
    {
       Arrays.sort(list);
       return list[list.length-1];
    }
    
}
