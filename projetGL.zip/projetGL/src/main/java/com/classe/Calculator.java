package com.classe;

import java.util.Arrays;

public class Calculator
{
    public int sum(int a, int b)
    {
        return a+b;
    }
    
      public  int minus(int a, int b)
    {
        return a-b;
    }
      
    public int divide(int a, int b)
    {
        return a/b;
    }
    
   
    
}
